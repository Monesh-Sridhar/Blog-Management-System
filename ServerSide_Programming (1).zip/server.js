var express = require('express')
var bodyParser = require('body-parser')
var MongoClient = require("mongodb").MongoClient
let db;
var blog_id=1
MongoClient.connect("mongodb://localhost:27017",{},(err,client)=>{
    if (err){
        console.log("Mongo DB Connection Error")
        process.exit(1)
    }
    db = client.db('blog')
    console.log("DB Connected")
    db.collection('blog').find({}).toArray(function(err,result){
        if(!err){
            if(result.length>0){
                blog_id = result[result.length-1].id +1
            }
            else{
                blog_id = 1
            }
        }
    })
});
var app = express()

app.set('view engine','ejs') 

var parser = bodyParser.urlencoded({extended:false});
app.get('/home',function(req,res){
    res.render('home')
});

app.get('/about',function(req,res){
    res.render('about')
});

app.get('/help',function (req,res){
    res.render('help')
})

app.get('/createBlog',function(req,res){
    res.render('createBlog')
})
app.post('/createBlog',parser,function(req,res){
        var data = {
            creator : req.body.creator,
            blog:req.body.blog,
            title:req.body.title,
            created:new Date(),
            id:blog_id
        }
        db.collection('blog').insertOne(data)
        blog_id+=1
        res.redirect('/home')
})

app.get('/viewBlog',function (req,res) {
    var data;
    db.collection('blog').find({}).toArray(function(err,result){
        if(!err){
    res.render('viewBlog',{data:result})
        }
    })
})

// assignment 2 - continuation

app.post("/editBlog",parser,function (req,res){
   
    res.render('editBlog',{data:req.body})
})

app.post("/editBlogSave",parser,function (req,res){
    var data = {
        creator : req.body.creator,
        blog:req.body.blog,
        title:req.body.title,
    }
    
      db.collection('blog').updateOne({id:parseInt(req.body.id)},{$set :data},(err,result)=>{
         if(!err){
             //console.log(result)
         }
         else{
             console.log("error")
         }
         
     })
    res.redirect('/viewBlog')
})

app.post('/deleteBlog',parser,function (req,res){

   

    db.collection('blog').deleteOne({id:parseInt(req.body.id)})


    res.redirect('viewBlog')
})

app.get("/search",parser,function (req,res){
    res.render('search',{data:[]})
})

app.post("/search",parser,function (req,res){

    var query = req.body.search_title

    db.collection('blog').find({title:query}).toArray(function(err,result){
        if(!err){
    res.render('search',{data:result})
        }
    })
})

app.listen(5000,()=>{
    console.log(" Server Started")
})

